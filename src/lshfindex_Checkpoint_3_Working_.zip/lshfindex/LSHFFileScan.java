package lshfindex;
import heap.*;
import java.io.IOException;

public class LSHFFileScan extends IndexFileScan {
    private LSHFBTreeFile btree;
    private LSHFBTFileScan scan;
    private boolean initialized;
    private LSHFBTLeafPage currentLeaf;
    private int currentEntryIndex;

    public LSHFFileScan(LSHFBTreeFile btree) throws IOException, ConstructPageException, PinPageException, UnpinPageException {
        this.btree = btree;
        this.initialized = false;
        this.currentLeaf = null;
        this.currentEntryIndex = 0;
    }

    public void initialize() throws IOException, ConstructPageException, PinPageException, UnpinPageException, KeyNotMatchException, IteratorException, IndexSearchException {
        if (!initialized) {
            System.out.println("🔍 Initializing LSHFFileScan...");
            this.scan = btree.new_scan(null, null);
            this.initialized = true;
        }
    }

    public void printTreeStructure() throws IOException, KeyNotMatchException, IteratorException, ConstructPageException, PinPageException, UnpinPageException, ScanIteratorException, IndexSearchException {
        if (!initialized) initialize();

        System.out.println("🔎 Scanning BTree Structure...");
        KeyDataEntry entry;

        while ((entry = scan.get_next()) != null) {
            if (entry.data instanceof LeafData) {
                System.out.println("📌 Leaf Node Record: " + entry.key);
            } else {
                System.out.println("🔹 Internal Node Key: " + entry.key);
            }
        }
        System.out.println("✅ BTree Structure Scan Completed.");
    }

    @Override
    public KeyDataEntry get_next() throws ScanIteratorException {
        try {
            if (!initialized) initialize();
            return scan.get_next();
        } catch (Exception e) {
            throw new ScanIteratorException("Error during get_next()"+ e);
        }
    }

    @Override
    public int keysize() {
        return 208;  // 100 shorts * 2 bytes each + 8 for RID
    }

    public KeyDataEntry getNextEntry() throws ScanIteratorException {
        try {
            if (!initialized) initialize();
            return scan.get_next();
        } catch (Exception e) {
            throw new ScanIteratorException(e, "Error retrieving next entry");
        }
    }

    public void closeScan() throws IOException, ScanIteratorException {
        try {
            System.out.println("🔄 Closing LSHFFileScan...");
            scan.DestroyLSHFBTreeFileScan();
        } catch (Exception e) {
            throw new ScanIteratorException(e, "Error closing scan");
        }
    }

    @Override
    public void delete_current() throws ScanDeleteException {
        throw new UnsupportedOperationException("delete_current() is not supported in LSHFFileScan.");
    }
}