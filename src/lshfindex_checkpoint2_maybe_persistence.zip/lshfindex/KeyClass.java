package lshfindex;
/** KeyClass: An abstarct class. It will be extended 
 *  to be integer key and string key.
 */    
public abstract class KeyClass {}
