package bufmgr;
import chainexception.*;

public class HashOperationException extends ChainException{

  public HashOperationException(Exception e, String name)
  { super(e, name); }
 


}




