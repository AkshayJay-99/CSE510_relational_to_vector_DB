package btree;

/** DeleteType class
 * define which delete type (naive or full) will be
 */  
public class DeleteFashion {
   public static final int NAIVE_DELETE=0;
   public static final int  FULL_DELETE=1;
} 
